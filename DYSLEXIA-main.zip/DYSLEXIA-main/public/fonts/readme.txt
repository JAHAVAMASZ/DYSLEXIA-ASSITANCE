
Place the OpenDyslexic font files in this directory:
- OpenDyslexic-Regular.woff2
- OpenDyslexic-Bold.woff2

You can download these fonts for free from:
https://opendyslexic.org/ or https://github.com/antijingoist/opendyslexic
